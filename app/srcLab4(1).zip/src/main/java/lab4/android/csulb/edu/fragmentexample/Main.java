package lab4.android.csulb.edu.fragmentexample;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.app.Activity;

public class Main extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
}
